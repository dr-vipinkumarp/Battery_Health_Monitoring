﻿Imports System
Imports System.Threading
Imports System.IO.Ports
Imports System.ComponentModel
Imports System.IO



Public Class Dashboard
    '------------------------------------------------
    Dim myPort As Array
    Delegate Sub SetTextCallback(ByVal [text] As String) 'Added to prevent threading errors during receiveing of data
    Dim PVAxisValue As String ' PVAxisValue is for Graph dataof Pack Voltage
    Dim FAULTValue As String
    Dim CTValue As String
    Dim STATEValue As String
    Dim SOHValue As String
    Dim SOCValue As String
    Dim CVValue As String
    Dim PEValue As String
    Dim PCValue As String
    Dim Timeframe As String
    Dim BINValue As String
    Dim Datacount As Integer
    Dim TimeCounter As Integer





    '------------------------------------------------
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        myPort = IO.Ports.SerialPort.GetPortNames()
        ComboBox1.Items.AddRange(myPort)

        Button2.Enabled = False
        TextBoxDataset.Text = Format(DateTime.Now(), "yyyyMMddHHmm")



    End Sub
    '------------------------------------------------
    Private Sub ComboBox1_Click(sender As System.Object, e As System.EventArgs) Handles ComboBox1.Click
    End Sub
    '------------------------------------------------
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        SerialPort1.PortName = ComboBox1.Text
        SerialPort1.BaudRate = ComboBox2.Text
        SerialPort1.Open()
        Button1.Enabled = False
        Button2.Enabled = True
        Button4.Enabled = True
        Timer1.Enabled = True
        Datacount = 0

        'Dim fPath As String = TextBoxFPath.Text & "" & TextBoxDataset.Text & "" & ".csv"
        ' Dim fPath As String = TextBoxFPath.Text & "" & TextBoxDataset.Text & "" & ".txt "
        'Dim afile As New System.IO.StreamWriter(fPath, True)
        'afile.WriteLine("PV" & " " & "," & " " & "PC" & " " & "," & " " & "PE" & " " & "," & " " & "CV1" & " " & "," & " " & "CV2" & " " & "," & " " & "CV3" & " " & "," & " " & "CV4" & " " & "," & " " & "CV5" & " " & "," & " " & "CV6" & " " & "," & " " & "CV7" & " " & "," & " " & "CV8" & " " & "," & " " & "CV9" & " " & "," & " " & "CV10" & " " & "," & " " & "CV11" & " " & "," & " " & "CV12" & " " & "," & " " & "CV13" & " " & "," & " " & "CV14" & " " & "," & " " & "CT1" & " " & "," & " " & "CT2" & " " & "," & " " & "CT3" & " " & "," & " " & "CT4" & " " & "," & " " & "CT5" & " " & "," & " " & "CT6" & " " & "," & " " & "SOC" & " " & "," & " " & "SOH" & " " & "," & " " & "PACK_FAULT" & " " & "," & " " & "PACK_STATE" & " " & "," & " " & "BIN")

        'afile.Close()
    End Sub
    '------------------------------------------------
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        SerialPort1.Write(RichTextBox1.Text & vbCr) 'concatenate with \n
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        SerialPort1.Close()
        Button1.Enabled = True
        Button2.Enabled = False
        Button4.Enabled = False
    End Sub

    Private Sub SerialPort1_DataReceived(sender As System.Object, e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        ReceivedText(SerialPort1.ReadExisting())
    End Sub

    Private Sub ReceivedText(ByVal [text] As String) 'input from ReadExisting
        If Me.RichTextBox2.InvokeRequired Then
            Dim x As New SetTextCallback(AddressOf ReceivedText)
            Me.Invoke(x, New Object() {(text)})
        Else
            Me.RichTextBox2.Text &= [text] 'append text
        End If
    End Sub







    'Private Sub TextBoxPV_TextChanged(sender As Object, e As EventArgs) Handles TextBoxPV.TextChanged
    ' Dim PVstr As String
    'Dim PVstrArr() As String
    'Dim PVcount As Integer
    '   PVstr = TextBoxPV.Text
    '  PVstrArr = PVstr.Split(" ")
    '  PVcount = PVstrArr.Length - 1

    '  PackVolt.Text = PVstrArr(1)

    ' End Sub

    Private Sub TextBoxPC_TextChanged(sender As Object, e As EventArgs) Handles TextBoxPC.TextChanged
        Dim PCstr As String
        Dim PCstrArr() As String
        Dim PCcount As Integer

        PCstr = TextBoxPC.Text
        PCstrArr = PCstr.Split(" ")
        PCcount = PCstrArr.Length - 1

        PCValue = PCstrArr(1)
        ' TextCurrent.Text = PCstrArr(1)

    End Sub

    Private Sub TextBoxPE_TextChanged(sender As Object, e As EventArgs) Handles TextBoxPE.TextChanged
        Dim PEstr As String
        Dim PEstrArr() As String
        Dim PEcount As Integer

        PEstr = TextBoxPE.Text
        PEstrArr = PEstr.Split(" ")
        PEcount = PEstrArr.Length - 1

        PEValue = PEstrArr(1)
        'TextBoxEnergy.Text = PEstrArr(1)
    End Sub



    Private Sub TextBoxCV_TextChanged(sender As Object, e As EventArgs) Handles TextBoxCV.TextChanged
        Dim CVstr As String
        Dim CVstrArr() As String
        Dim CVcount As Integer

        CVstr = TextBoxCV.Text
        CVstrArr = CVstr.Split(" ")
        CVcount = CVstrArr.Length - 1


        CVValue = CVstrArr(1)
        LableCV1.Text = CVValue

    End Sub



    ' Private Sub TextBoxCT_TextChanged(sender As Object, e As EventArgs) Handles TextBoxCTHEAD.TextChanged
    'Dim CTstr As String
    'Dim CTstrArr() As String
    'Dim CTcount As Integer
    '   CTstr = TextBoxCTHEAD.Text
    '   CTstrArr = CTstr.Split(" ")
    '   CTcount = CTstrArr.Length - 1

    ' TextBoxCT1.Text = CTstrArr(1)
    ' End Sub

    ' Private Sub TextBox29_TextChanged(sender As Object, e As EventArgs) Handles TextBox29.TextChanged
    'Dim MaxCVstr As String
    'Dim MaxCVstrArr() As String
    'Dim MaxCVcount As Integer
    '    MaxCVstr = TextBox29.Text
    '    MaxCVstrArr = MaxCVstr.Split(" ")
    '   MaxCVcount = MaxCVstrArr.Length - 1

    'TextBoxMaxCV.Text = MaxCVstrArr(2) / 100
    ' End Sub

    'Private Sub TextBox30_TextChanged(sender As Object, e As EventArgs) Handles TextBox30.TextChanged
    'Dim MinCVstr As String
    'Dim MinCVstrArr() As String
    'Dim MinCVcount As Integer
    '  MinCVstr = TextBox30.Text
    ' MinCVstrArr = MinCVstr.Split(" ")
    ' MinCVcount = MinCVstrArr.Length - 1

    'TextBoxMinCV.Text = MinCVstrArr(2) / 100
    ' End Sub



    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'Dim StingPV = RichTextBox2.Text

        'Dim splitPE = RichTextBox2.Text.Split("|"c)

        ' If (splitPE.Count = 4) Then
        'RichTextBox1.Text = Split(0).ToString

        'TextBoxPC.Text = Split(1).ToString
        'TextBox1.Text = Split(2).ToString
        'TextBox10.Text = Split(3).ToString

        'End If



        'Timeframe = Format(DateTime.Now(), "yyyy-mm-dd-HH-mm-ss")
        TimeCounter = TimeCounter + 500

        Dim str As String
        Dim strArr() As String
        Dim count As Integer


        str = RichTextBox2.Text
        strArr = str.Split("|")
        count = strArr.Length - 1
        TextBoxCount.Text = count



        If (count = 29) Then   '27
            LablePV.Text = strArr(0)
            PVAxis.Text = strArr(0)
            LablePC.Text = strArr(1)
            TextBoxPC.Text = strArr(1)
            LablePE.Text = strArr(2)
            TextBoxPE.Text = strArr(2)
            'LableCV1.Text = strArr(3) Split in Above
            TextBoxCV.Text = strArr(3)
            LableCV2.Text = (strArr(4))
            LableCV3.Text = (strArr(5))
            LableCV4.Text = (strArr(6))
            LableCV5.Text = (strArr(7))
            LableCV6.Text = (strArr(8))
            LableCV7.Text = (strArr(9))
            LableCV8.Text = (strArr(10))
            LableCV9.Text = (strArr(11))
            LableCV10.Text = (strArr(12))
            LableCV11.Text = (strArr(13))
            LableCV12.Text = (strArr(14))
            LableCV13.Text = (strArr(15))
            LableCV14.Text = (strArr(16))
            'LableCT1.Text = strArr(18) Split in Below
            TextBoxCT.Text = strArr(18)
            'Label4.Text = strArr(18)
            LableCT2.Text = strArr(19)
            LableCT3.Text = strArr(20)
            LableCT4.Text = strArr(21)
            LableCT5.Text = strArr(22)
            LableCT6.Text = strArr(23)
            LableSOC.Text = strArr(25)
            TextBoxSoC.Text = strArr(25)
            LableSOH.Text = strArr(26)
            TextBoxSoH.Text = strArr(26)
            LablePACKFAULT.Text = strArr(27)
            TextBoxFAULT.Text = strArr(27)
            LablePACKSTATE.Text = strArr(28)
            TextBoxPackState.Text = strArr(28)
            LableBIN.Text = strArr(29)
            TextBoxBIN.Text = strArr(29)


            'TextBox26.Text = strArr(28)
            'TextBox27.Text = strArr(29)
            'TextBox29.Text = strArr(41)
            'TextBox30.Text = strArr(42)


            'ElseIf (count = 0) Then

            'Dim PVstr As String
            'Dim PVstrArr() As String
            'Dim PVcount As Integer
            'Dim CTstr As String
            'Dim CTstrArr() As String
            'Dim CTcount As Integer

            ' PVstr = LablePV.Text
            ' PVstrArr = PVstr.Split(" ")
            ' PVcount = PVstrArr.Length - 1

            ' CTstr = LableCT1.Text
            ' CTstrArr = CTstr.Split(" ")
            ' CTcount = CTstrArr.Length - 1

            ' TextBoxPackVoltage.Text = PVstrArr(1)
            ' TexBoxtCTHead.Text = LableCT3.Text







            'Else
            '  MsgBox("Invalid data sending by BMS, Please verify the string transmitting by BMS")

        End If


        RichTextBox2.Text = ""
        Me.Chart1.Series("CV1").Points.AddXY(DateTime.Now.ToString(), LableCV1.Text)

        Me.Chart1.Series("CV2").Points.AddXY(DateTime.Now.ToString(), LableCV2.Text)
        Me.Chart1.Series("CV3").Points.AddXY(DateTime.Now.ToString(), LableCV4.Text)
        Me.Chart1.Series("CV4").Points.AddXY(DateTime.Now.ToString(), LableCV4.Text)
        Me.Chart1.Series("CV5").Points.AddXY(DateTime.Now.ToString(), LableCV5.Text)
        Me.Chart1.Series("CV6").Points.AddXY(DateTime.Now.ToString(), LableCV6.Text)
        Me.Chart1.Series("CV7").Points.AddXY(DateTime.Now.ToString(), LableCV7.Text)
        Me.Chart1.Series("CV8").Points.AddXY(DateTime.Now.ToString(), LableCV8.Text)
        Me.Chart1.Series("CV9").Points.AddXY(DateTime.Now.ToString(), LableCV9.Text)
        Me.Chart1.Series("CV10").Points.AddXY(DateTime.Now.ToString(), LableCV10.Text)
        Me.Chart1.Series("CV11").Points.AddXY(DateTime.Now.ToString(), LableCV11.Text)
        Me.Chart1.Series("CV12").Points.AddXY(DateTime.Now.ToString(), LableCV12.Text)
        Me.Chart1.Series("CV13").Points.AddXY(DateTime.Now.ToString(), LableCV13.Text)
        Me.Chart1.Series("CV14").Points.AddXY(DateTime.Now.ToString(), LableCV14.Text)


        Me.Chart2.Series("CT1").Points.AddXY(DateTime.Now.ToString(), LableCT1.Text)
        Me.Chart2.Series("CT2").Points.AddXY(DateTime.Now.ToString(), LableCT2.Text)
        Me.Chart2.Series("CT3").Points.AddXY(DateTime.Now.ToString(), LableCT3.Text)
        Me.Chart2.Series("CT4").Points.AddXY(DateTime.Now.ToString(), LableCT4.Text)
        Me.Chart2.Series("CT5").Points.AddXY(DateTime.Now.ToString(), LableCT5.Text)
        Me.Chart2.Series("CT6").Points.AddXY(DateTime.Now.ToString(), LableCT6.Text)



        Dim bpath As String = TextBoxFPath.Text & "" & "\" & "" & TextBoxDataset.Text & "" & ".csv"
        Dim bfile As New System.IO.StreamWriter(bpath, True)
        'afile.WriteLine("PV" & " " & "," & " " & "PC" & " " & "," & " " & "PE" & " " & "," & " " & "CV1" & " " & "," & " " & "CV2" & " " & "," & " " & "CV3" & " " & "," & " " & "CV4" & " " & "," & " " & "CV5" & " " & "," & " " & "CV6" & " " & "," & " " & "CV7" & " " & "," & " " & "CV8" & " " & "," & " " & "CV9" & " " & "," & " " & "CV10" & " " & "," & " " & "CV11" & " " & "," & " " & "CV12" & " " & "," & " " & "CV13" & " " & "," & " " & "CV14" & " " & "," & " " & "CT1" & " " & "," & " " & "CT2" & " " & "," & " " & "CT3" & " " & "," & " " & "CT4" & " " & "," & " " & "CT5" & " " & "," & " " & "CT6" & " " & "," & " " & "SOC" & " " & "," & " " & "SOH" & " " & "," & " " & "PACK_FAULT" & " " & "," & " " & "PACK_STATE" & " " & "," & " " & "BIN")

        If (Datacount = 0) Then
            bfile.WriteLine("TimeCount(mS)" & "" & "," & "" & "PV" & " " & "," & " " & "PC" & " " & "," & " " & "PE" & " " & "," & " " & "CV1" & " " & "," & " " & "CV2" & " " & "," & " " & "CV3" & " " & "," & " " & "CV4" & " " & "," & " " & "CV5" & " " & "," & " " & "CV6" & " " & "," & " " & "CV7" & " " & "," & " " & "CV8" & " " & "," & " " & "CV9" & " " & "," & " " & "CV10" & " " & "," & " " & "CV11" & " " & "," & " " & "CV12" & " " & "," & " " & "CV13" & " " & "," & " " & "CV14" & " " & "," & " " & "CT1" & " " & "," & " " & "CT2" & " " & "," & " " & "CT3" & " " & "," & " " & "CT4" & " " & "," & " " & "CT5" & " " & "," & " " & "CT6" & " " & "," & " " & "SOC" & " " & "," & " " & "SOH" & " " & "," & " " & "PACK_FAULT" & " " & "," & " " & "PACK_STATE" & " " & "," & " " & "BIN")
            Datacount = 1
            bfile.Close()

        Else
            bfile.WriteLine(TimeCounter & "" & "," & "" & PVAxisValue & " " & "," & " " & PCValue & " " & "," & " " & PEValue & " " & "," & " " & CVValue & " " & "," & " " & LableCV2.Text & " " & "," & " " & LableCV3.Text & " " & "," & " " & LableCV4.Text & " " & "," & " " & LableCV5.Text & " " & "," & " " & LableCV6.Text & " " & "," & " " & LableCV7.Text & " " & "," & " " & LableCV8.Text & " " & "," & " " & LableCV9.Text & " " & "," & " " & LableCV10.Text & " " & "," & " " & LableCV11.Text & " " & "," & " " & LableCV12.Text & " " & "," & " " & LableCV13.Text & " " & "," & " " & LableCV14.Text & " " & "," & " " & CTValue & " " & "," & " " & LableCT2.Text & " " & "," & " " & LableCT3.Text & " " & "," & " " & LableCT4.Text & " " & "," & " " & LableCT5.Text & " " & "," & " " & LableCT6.Text & " " & "," & " " & SOCValue & " " & "," & " " & SOHValue & " " & "," & " " & FAULTValue & " " & "," & " " & STATEValue & " " & "," & " " & BINValue)
            bfile.Close()
        End If












    End Sub



    Private Sub PVAxis_TextChanged(sender As Object, e As EventArgs) Handles PVAxis.TextChanged
        Dim PVstr As String
        Dim PVstrArr() As String
        Dim PVcount As Integer


        PVstr = PVAxis.Text
        PVstrArr = PVstr.Split(" ")
        PVcount = PVstrArr.Length - 1

        PVAxisValue = PVstrArr(1)


    End Sub

    Private Sub TextBoxSoC_TextChanged(sender As Object, e As EventArgs) Handles TextBoxSoC.TextChanged
        Dim SOCstr As String
        Dim SOCstrArr() As String
        Dim SOCcount As Integer

        SOCstr = TextBoxSoC.Text
        SOCstrArr = SOCstr.Split(" ")
        SOCcount = SOCstrArr.Length - 1

        SOCValue = SOCstrArr(1)
    End Sub

    Private Sub TextBoxSoH_TextChanged(sender As Object, e As EventArgs) Handles TextBoxSoH.TextChanged
        Dim SOHstr As String
        Dim SOHstrArr() As String
        Dim SOHcount As Integer

        SOHstr = TextBoxSoH.Text
        SOHstrArr = SOHstr.Split(" ")
        SOHcount = SOHstrArr.Length - 1

        SOHValue = SOHstrArr(1)
    End Sub

    Private Sub TextBoxPackState_TextChanged(sender As Object, e As EventArgs) Handles TextBoxPackState.TextChanged
        Dim STATEstr As String
        Dim STATEstrArr() As String
        Dim STATEcount As Integer

        STATEstr = TextBoxPackState.Text
        STATEstrArr = STATEstr.Split(" ")
        STATEcount = STATEstrArr.Length - 1

        STATEValue = STATEstrArr(1)
    End Sub

    Private Sub TextBoxCT_TextChanged(sender As Object, e As EventArgs) Handles TextBoxCT.TextChanged
        Dim CTstr As String
        Dim CTstrArr() As String
        Dim CTcount As Integer

        CTstr = TextBoxCT.Text
        CTstrArr = CTstr.Split(" ")
        CTcount = CTstrArr.Length - 1

        CTValue = CTstrArr(1)
        LableCT1.Text = CTValue
    End Sub

    Private Sub TextBoxFAULT_TextChanged(sender As Object, e As EventArgs) Handles TextBoxFAULT.TextChanged
        Dim FAULTstr As String
        Dim FAULTstrArr() As String
        Dim FAULTcount As Integer

        FAULTstr = TextBoxFAULT.Text
        FAULTstrArr = FAULTstr.Split(" ")
        FAULTcount = FAULTstrArr.Length - 1

        FAULTValue = FAULTstrArr(1)
    End Sub

    Private Sub TextBoxBIN_TextChanged(sender As Object, e As EventArgs) Handles TextBoxBIN.TextChanged
        Dim BINstr As String
        Dim BINstrArr() As String
        Dim BINcount As Integer

        BINstr = TextBoxBIN.Text
        BINstrArr = BINstr.Split(" ")
        BINcount = BINstrArr.Length - 1

        BINValue = BINstrArr(1)
    End Sub













    'Packet
    'PV 48.99|PC -0.007220|PE 95.123|CV 3445|3389|3423|3437|3362|3439|3416|3340|3412|3422|3397|3421|3412|3428|CT 33.63|36.47|36.12|36.83|37.51|50|SOC 53.32|SOH 100.00 | PACK FAULT: 3|PACK_STATE: 1| BIN: ABCDS
    '     1         2           3         4     5    6   7    8     9   10   11    12  13   14   15   16   17    18      19    20    21     22   23     24        25           26               27          28




End Class
