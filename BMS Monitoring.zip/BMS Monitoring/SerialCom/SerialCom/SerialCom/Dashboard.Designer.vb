﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend1 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series2 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series3 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series4 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series5 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series6 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series7 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series8 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series9 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series10 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series11 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series12 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series13 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series14 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dashboard))
        Dim ChartArea2 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend2 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series15 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series16 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series17 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series18 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series19 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series20 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.TextBoxPV = New System.Windows.Forms.TextBox()
        Me.TextBoxPC = New System.Windows.Forms.TextBox()
        Me.TextBoxPE = New System.Windows.Forms.TextBox()
        Me.TextBoxCV = New System.Windows.Forms.TextBox()
        Me.LablePV = New System.Windows.Forms.Label()
        Me.LablePE = New System.Windows.Forms.Label()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.TextBoxPACKFAULT = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBoxCTHEAD = New System.Windows.Forms.TextBox()
        Me.TextBoxSoH = New System.Windows.Forms.TextBox()
        Me.TextBoxSoC = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.LableCV1 = New System.Windows.Forms.Label()
        Me.LableCV2 = New System.Windows.Forms.Label()
        Me.LableCV3 = New System.Windows.Forms.Label()
        Me.LableCV4 = New System.Windows.Forms.Label()
        Me.LableCV5 = New System.Windows.Forms.Label()
        Me.LableCV6 = New System.Windows.Forms.Label()
        Me.LableCV7 = New System.Windows.Forms.Label()
        Me.LableCV8 = New System.Windows.Forms.Label()
        Me.LableCV9 = New System.Windows.Forms.Label()
        Me.LableCV10 = New System.Windows.Forms.Label()
        Me.LableCV11 = New System.Windows.Forms.Label()
        Me.LableCV12 = New System.Windows.Forms.Label()
        Me.LableCV13 = New System.Windows.Forms.Label()
        Me.LableCV14 = New System.Windows.Forms.Label()
        Me.LableCT1 = New System.Windows.Forms.Label()
        Me.LableCT2 = New System.Windows.Forms.Label()
        Me.LableCT3 = New System.Windows.Forms.Label()
        Me.LableCT4 = New System.Windows.Forms.Label()
        Me.LableCT5 = New System.Windows.Forms.Label()
        Me.LableCT6 = New System.Windows.Forms.Label()
        Me.Chart2 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.LablePC = New System.Windows.Forms.Label()
        Me.LableSOC = New System.Windows.Forms.Label()
        Me.LableSOH = New System.Windows.Forms.Label()
        Me.LablePACKFAULT = New System.Windows.Forms.Label()
        Me.LablePACKSTATE = New System.Windows.Forms.Label()
        Me.LableBIN = New System.Windows.Forms.Label()
        Me.TextBoxPackVoltage = New System.Windows.Forms.TextBox()
        Me.TexBoxtCTHead = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BoudRate = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TextBoxFPath = New System.Windows.Forms.TextBox()
        Me.PVAxis = New System.Windows.Forms.TextBox()
        Me.TextBoxCount = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBoxCT = New System.Windows.Forms.TextBox()
        Me.TextBoxPackState = New System.Windows.Forms.TextBox()
        Me.TextBoxFAULT = New System.Windows.Forms.TextBox()
        Me.TextBoxDataset = New System.Windows.Forms.TextBox()
        Me.TextBoxBIN = New System.Windows.Forms.TextBox()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Purple
        Me.Button1.Location = New System.Drawing.Point(6, 177)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(92, 28)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Connect Device"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(1219, 536)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 50)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "0"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'ComboBox1
        '
        Me.ComboBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox1.BackColor = System.Drawing.Color.White
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(6, 109)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(183, 28)
        Me.ComboBox1.TabIndex = 3
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox1.BackColor = System.Drawing.Color.White
        Me.RichTextBox1.ForeColor = System.Drawing.Color.White
        Me.RichTextBox1.Location = New System.Drawing.Point(1213, 540)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(37, 25)
        Me.RichTextBox1.TabIndex = 4
        Me.RichTextBox1.Text = ""
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.RichTextBox2.Location = New System.Drawing.Point(115, 12)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(82, 26)
        Me.RichTextBox2.TabIndex = 5
        Me.RichTextBox2.Text = ""
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(1189, 538)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 20)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Input"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(1221, 546)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 20)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Output"
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.Purple
        Me.Button4.Location = New System.Drawing.Point(104, 177)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(87, 28)
        Me.Button4.TabIndex = 8
        Me.Button4.Text = "Disconnect Device"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'SerialPort1
        '
        Me.SerialPort1.PortName = "COM6"
        '
        'ComboBox2
        '
        Me.ComboBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"9600", "38400", "57600", "115200"})
        Me.ComboBox2.Location = New System.Drawing.Point(6, 141)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(183, 28)
        Me.ComboBox2.TabIndex = 9
        '
        'TextBoxPV
        '
        Me.TextBoxPV.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxPV.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxPV.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxPV.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxPV.Location = New System.Drawing.Point(682, 50)
        Me.TextBoxPV.Name = "TextBoxPV"
        Me.TextBoxPV.Size = New System.Drawing.Size(74, 13)
        Me.TextBoxPV.TabIndex = 13
        '
        'TextBoxPC
        '
        Me.TextBoxPC.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxPC.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxPC.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxPC.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxPC.Location = New System.Drawing.Point(814, 49)
        Me.TextBoxPC.Name = "TextBoxPC"
        Me.TextBoxPC.Size = New System.Drawing.Size(76, 13)
        Me.TextBoxPC.TabIndex = 14
        '
        'TextBoxPE
        '
        Me.TextBoxPE.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxPE.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxPE.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxPE.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxPE.Location = New System.Drawing.Point(738, 50)
        Me.TextBoxPE.Name = "TextBoxPE"
        Me.TextBoxPE.Size = New System.Drawing.Size(70, 13)
        Me.TextBoxPE.TabIndex = 15
        '
        'TextBoxCV
        '
        Me.TextBoxCV.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxCV.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxCV.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxCV.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxCV.Location = New System.Drawing.Point(742, 12)
        Me.TextBoxCV.Name = "TextBoxCV"
        Me.TextBoxCV.Size = New System.Drawing.Size(76, 13)
        Me.TextBoxCV.TabIndex = 16
        '
        'LablePV
        '
        Me.LablePV.AutoSize = True
        Me.LablePV.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LablePV.ForeColor = System.Drawing.Color.Lime
        Me.LablePV.Location = New System.Drawing.Point(16, 54)
        Me.LablePV.Name = "LablePV"
        Me.LablePV.Size = New System.Drawing.Size(319, 55)
        Me.LablePV.TabIndex = 47
        Me.LablePV.Text = "Pack Voltage"
        Me.LablePV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LablePE
        '
        Me.LablePE.AutoSize = True
        Me.LablePE.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LablePE.Location = New System.Drawing.Point(624, 31)
        Me.LablePE.Name = "LablePE"
        Me.LablePE.Size = New System.Drawing.Size(148, 29)
        Me.LablePE.TabIndex = 49
        Me.LablePE.Text = "Pack Energy"
        Me.LablePE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Chart1
        '
        ChartArea1.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea1)
        Legend1.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend1)
        Me.Chart1.Location = New System.Drawing.Point(8, 322)
        Me.Chart1.Name = "Chart1"
        Series1.ChartArea = "ChartArea1"
        Series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series1.Legend = "Legend1"
        Series1.Name = "CV1"
        Series2.ChartArea = "ChartArea1"
        Series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series2.Legend = "Legend1"
        Series2.Name = "CV2"
        Series3.ChartArea = "ChartArea1"
        Series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series3.Legend = "Legend1"
        Series3.Name = "CV3"
        Series4.ChartArea = "ChartArea1"
        Series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series4.Legend = "Legend1"
        Series4.Name = "CV4"
        Series5.ChartArea = "ChartArea1"
        Series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series5.Legend = "Legend1"
        Series5.Name = "CV5"
        Series6.ChartArea = "ChartArea1"
        Series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series6.Legend = "Legend1"
        Series6.Name = "CV6"
        Series7.ChartArea = "ChartArea1"
        Series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series7.Legend = "Legend1"
        Series7.Name = "CV7"
        Series8.ChartArea = "ChartArea1"
        Series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series8.Legend = "Legend1"
        Series8.Name = "CV8"
        Series9.ChartArea = "ChartArea1"
        Series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series9.Legend = "Legend1"
        Series9.Name = "CV9"
        Series10.ChartArea = "ChartArea1"
        Series10.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series10.Legend = "Legend1"
        Series10.Name = "CV10"
        Series11.ChartArea = "ChartArea1"
        Series11.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series11.Legend = "Legend1"
        Series11.Name = "CV11"
        Series12.ChartArea = "ChartArea1"
        Series12.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series12.Legend = "Legend1"
        Series12.Name = "CV12"
        Series13.ChartArea = "ChartArea1"
        Series13.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series13.Legend = "Legend1"
        Series13.Name = "CV13"
        Series14.ChartArea = "ChartArea1"
        Series14.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series14.Legend = "Legend1"
        Series14.Name = "CV14"
        Me.Chart1.Series.Add(Series1)
        Me.Chart1.Series.Add(Series2)
        Me.Chart1.Series.Add(Series3)
        Me.Chart1.Series.Add(Series4)
        Me.Chart1.Series.Add(Series5)
        Me.Chart1.Series.Add(Series6)
        Me.Chart1.Series.Add(Series7)
        Me.Chart1.Series.Add(Series8)
        Me.Chart1.Series.Add(Series9)
        Me.Chart1.Series.Add(Series10)
        Me.Chart1.Series.Add(Series11)
        Me.Chart1.Series.Add(Series12)
        Me.Chart1.Series.Add(Series13)
        Me.Chart1.Series.Add(Series14)
        Me.Chart1.Size = New System.Drawing.Size(761, 266)
        Me.Chart1.TabIndex = 68
        Me.Chart1.Text = "Chart1"
        '
        'TextBoxPACKFAULT
        '
        Me.TextBoxPACKFAULT.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxPACKFAULT.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPACKFAULT.Location = New System.Drawing.Point(1181, 54)
        Me.TextBoxPACKFAULT.Name = "TextBoxPACKFAULT"
        Me.TextBoxPACKFAULT.Size = New System.Drawing.Size(65, 24)
        Me.TextBoxPACKFAULT.TabIndex = 74
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(1114, 275)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(50, 20)
        Me.TextBox28.TabIndex = 69
        '
        'TextBoxCTHEAD
        '
        Me.TextBoxCTHEAD.Location = New System.Drawing.Point(1030, 275)
        Me.TextBoxCTHEAD.Name = "TextBoxCTHEAD"
        Me.TextBoxCTHEAD.Size = New System.Drawing.Size(50, 20)
        Me.TextBoxCTHEAD.TabIndex = 83
        '
        'TextBoxSoH
        '
        Me.TextBoxSoH.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxSoH.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxSoH.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxSoH.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxSoH.Location = New System.Drawing.Point(640, 12)
        Me.TextBoxSoH.Name = "TextBoxSoH"
        Me.TextBoxSoH.Size = New System.Drawing.Size(96, 13)
        Me.TextBoxSoH.TabIndex = 84
        '
        'TextBoxSoC
        '
        Me.TextBoxSoC.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxSoC.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxSoC.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxSoC.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxSoC.Location = New System.Drawing.Point(717, 31)
        Me.TextBoxSoC.Name = "TextBoxSoC"
        Me.TextBoxSoC.Size = New System.Drawing.Size(73, 13)
        Me.TextBoxSoC.TabIndex = 85
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(904, 9)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(189, 70)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 92
        Me.PictureBox1.TabStop = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'LableCV1
        '
        Me.LableCV1.AutoSize = True
        Me.LableCV1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV1.Location = New System.Drawing.Point(8, 37)
        Me.LableCV1.Name = "LableCV1"
        Me.LableCV1.Size = New System.Drawing.Size(46, 24)
        Me.LableCV1.TabIndex = 102
        Me.LableCV1.Text = "CV1"
        '
        'LableCV2
        '
        Me.LableCV2.AutoSize = True
        Me.LableCV2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV2.Location = New System.Drawing.Point(98, 37)
        Me.LableCV2.Name = "LableCV2"
        Me.LableCV2.Size = New System.Drawing.Size(46, 24)
        Me.LableCV2.TabIndex = 103
        Me.LableCV2.Text = "CV2"
        '
        'LableCV3
        '
        Me.LableCV3.AutoSize = True
        Me.LableCV3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV3.Location = New System.Drawing.Point(188, 37)
        Me.LableCV3.Name = "LableCV3"
        Me.LableCV3.Size = New System.Drawing.Size(46, 24)
        Me.LableCV3.TabIndex = 104
        Me.LableCV3.Text = "CV3"
        '
        'LableCV4
        '
        Me.LableCV4.AutoSize = True
        Me.LableCV4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV4.Location = New System.Drawing.Point(278, 37)
        Me.LableCV4.Name = "LableCV4"
        Me.LableCV4.Size = New System.Drawing.Size(46, 24)
        Me.LableCV4.TabIndex = 105
        Me.LableCV4.Text = "CV4"
        '
        'LableCV5
        '
        Me.LableCV5.AutoSize = True
        Me.LableCV5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV5.Location = New System.Drawing.Point(368, 37)
        Me.LableCV5.Name = "LableCV5"
        Me.LableCV5.Size = New System.Drawing.Size(46, 24)
        Me.LableCV5.TabIndex = 106
        Me.LableCV5.Text = "CV5"
        '
        'LableCV6
        '
        Me.LableCV6.AutoSize = True
        Me.LableCV6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV6.Location = New System.Drawing.Point(458, 37)
        Me.LableCV6.Name = "LableCV6"
        Me.LableCV6.Size = New System.Drawing.Size(46, 24)
        Me.LableCV6.TabIndex = 107
        Me.LableCV6.Text = "CV6"
        '
        'LableCV7
        '
        Me.LableCV7.AutoSize = True
        Me.LableCV7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV7.Location = New System.Drawing.Point(548, 37)
        Me.LableCV7.Name = "LableCV7"
        Me.LableCV7.Size = New System.Drawing.Size(46, 24)
        Me.LableCV7.TabIndex = 108
        Me.LableCV7.Text = "CV7"
        '
        'LableCV8
        '
        Me.LableCV8.AutoSize = True
        Me.LableCV8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV8.Location = New System.Drawing.Point(638, 37)
        Me.LableCV8.Name = "LableCV8"
        Me.LableCV8.Size = New System.Drawing.Size(46, 24)
        Me.LableCV8.TabIndex = 109
        Me.LableCV8.Text = "CV8"
        '
        'LableCV9
        '
        Me.LableCV9.AutoSize = True
        Me.LableCV9.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV9.Location = New System.Drawing.Point(728, 37)
        Me.LableCV9.Name = "LableCV9"
        Me.LableCV9.Size = New System.Drawing.Size(46, 24)
        Me.LableCV9.TabIndex = 110
        Me.LableCV9.Text = "CV9"
        '
        'LableCV10
        '
        Me.LableCV10.AutoSize = True
        Me.LableCV10.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV10.Location = New System.Drawing.Point(818, 37)
        Me.LableCV10.Name = "LableCV10"
        Me.LableCV10.Size = New System.Drawing.Size(56, 24)
        Me.LableCV10.TabIndex = 111
        Me.LableCV10.Text = "CV10"
        '
        'LableCV11
        '
        Me.LableCV11.AutoSize = True
        Me.LableCV11.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV11.Location = New System.Drawing.Point(918, 37)
        Me.LableCV11.Name = "LableCV11"
        Me.LableCV11.Size = New System.Drawing.Size(56, 24)
        Me.LableCV11.TabIndex = 112
        Me.LableCV11.Text = "CV11"
        '
        'LableCV12
        '
        Me.LableCV12.AutoSize = True
        Me.LableCV12.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV12.Location = New System.Drawing.Point(1018, 37)
        Me.LableCV12.Name = "LableCV12"
        Me.LableCV12.Size = New System.Drawing.Size(56, 24)
        Me.LableCV12.TabIndex = 113
        Me.LableCV12.Text = "CV12"
        '
        'LableCV13
        '
        Me.LableCV13.AutoSize = True
        Me.LableCV13.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV13.Location = New System.Drawing.Point(1118, 37)
        Me.LableCV13.Name = "LableCV13"
        Me.LableCV13.Size = New System.Drawing.Size(56, 24)
        Me.LableCV13.TabIndex = 114
        Me.LableCV13.Text = "CV13"
        '
        'LableCV14
        '
        Me.LableCV14.AutoSize = True
        Me.LableCV14.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCV14.Location = New System.Drawing.Point(1218, 37)
        Me.LableCV14.Name = "LableCV14"
        Me.LableCV14.Size = New System.Drawing.Size(56, 24)
        Me.LableCV14.TabIndex = 115
        Me.LableCV14.Text = "CV14"
        '
        'LableCT1
        '
        Me.LableCT1.AutoSize = True
        Me.LableCT1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCT1.Location = New System.Drawing.Point(6, 33)
        Me.LableCT1.Name = "LableCT1"
        Me.LableCT1.Size = New System.Drawing.Size(45, 24)
        Me.LableCT1.TabIndex = 116
        Me.LableCT1.Text = "CT1"
        '
        'LableCT2
        '
        Me.LableCT2.AutoSize = True
        Me.LableCT2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCT2.Location = New System.Drawing.Point(97, 33)
        Me.LableCT2.Name = "LableCT2"
        Me.LableCT2.Size = New System.Drawing.Size(45, 24)
        Me.LableCT2.TabIndex = 117
        Me.LableCT2.Text = "CT2"
        '
        'LableCT3
        '
        Me.LableCT3.AutoSize = True
        Me.LableCT3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCT3.Location = New System.Drawing.Point(188, 33)
        Me.LableCT3.Name = "LableCT3"
        Me.LableCT3.Size = New System.Drawing.Size(45, 24)
        Me.LableCT3.TabIndex = 118
        Me.LableCT3.Text = "CT3"
        '
        'LableCT4
        '
        Me.LableCT4.AutoSize = True
        Me.LableCT4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCT4.Location = New System.Drawing.Point(279, 33)
        Me.LableCT4.Name = "LableCT4"
        Me.LableCT4.Size = New System.Drawing.Size(45, 24)
        Me.LableCT4.TabIndex = 119
        Me.LableCT4.Text = "CT4"
        '
        'LableCT5
        '
        Me.LableCT5.AutoSize = True
        Me.LableCT5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCT5.Location = New System.Drawing.Point(370, 33)
        Me.LableCT5.Name = "LableCT5"
        Me.LableCT5.Size = New System.Drawing.Size(45, 24)
        Me.LableCT5.TabIndex = 120
        Me.LableCT5.Text = "CT5"
        '
        'LableCT6
        '
        Me.LableCT6.AutoSize = True
        Me.LableCT6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableCT6.Location = New System.Drawing.Point(461, 33)
        Me.LableCT6.Name = "LableCT6"
        Me.LableCT6.Size = New System.Drawing.Size(45, 24)
        Me.LableCT6.TabIndex = 121
        Me.LableCT6.Text = "CT6"
        '
        'Chart2
        '
        ChartArea2.Name = "ChartArea1"
        Me.Chart2.ChartAreas.Add(ChartArea2)
        Legend2.Name = "Legend1"
        Me.Chart2.Legends.Add(Legend2)
        Me.Chart2.Location = New System.Drawing.Point(775, 391)
        Me.Chart2.Name = "Chart2"
        Series15.ChartArea = "ChartArea1"
        Series15.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series15.Legend = "Legend1"
        Series15.Name = "CT1"
        Series16.ChartArea = "ChartArea1"
        Series16.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series16.Legend = "Legend1"
        Series16.Name = "CT2"
        Series17.ChartArea = "ChartArea1"
        Series17.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series17.Legend = "Legend1"
        Series17.Name = "CT3"
        Series18.ChartArea = "ChartArea1"
        Series18.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series18.Legend = "Legend1"
        Series18.Name = "CT4"
        Series19.ChartArea = "ChartArea1"
        Series19.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series19.Legend = "Legend1"
        Series19.Name = "CT5"
        Series20.ChartArea = "ChartArea1"
        Series20.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series20.Legend = "Legend1"
        Series20.Name = "CT6"
        Me.Chart2.Series.Add(Series15)
        Me.Chart2.Series.Add(Series16)
        Me.Chart2.Series.Add(Series17)
        Me.Chart2.Series.Add(Series18)
        Me.Chart2.Series.Add(Series19)
        Me.Chart2.Series.Add(Series20)
        Me.Chart2.Size = New System.Drawing.Size(521, 197)
        Me.Chart2.TabIndex = 130
        Me.Chart2.Text = "Chart2"
        '
        'LablePC
        '
        Me.LablePC.AutoSize = True
        Me.LablePC.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LablePC.Location = New System.Drawing.Point(387, 31)
        Me.LablePC.Name = "LablePC"
        Me.LablePC.Size = New System.Drawing.Size(151, 29)
        Me.LablePC.TabIndex = 131
        Me.LablePC.Text = "Pack Current"
        Me.LablePC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LableSOC
        '
        Me.LableSOC.AutoSize = True
        Me.LableSOC.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableSOC.Location = New System.Drawing.Point(387, 107)
        Me.LableSOC.Name = "LableSOC"
        Me.LableSOC.Size = New System.Drawing.Size(65, 29)
        Me.LableSOC.TabIndex = 132
        Me.LableSOC.Text = "SOC"
        Me.LableSOC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LableSOH
        '
        Me.LableSOH.AutoSize = True
        Me.LableSOH.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableSOH.Location = New System.Drawing.Point(626, 107)
        Me.LableSOH.Name = "LableSOH"
        Me.LableSOH.Size = New System.Drawing.Size(65, 29)
        Me.LableSOH.TabIndex = 133
        Me.LableSOH.Text = "SOH"
        Me.LableSOH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LablePACKFAULT
        '
        Me.LablePACKFAULT.AutoSize = True
        Me.LablePACKFAULT.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LablePACKFAULT.Location = New System.Drawing.Point(820, 31)
        Me.LablePACKFAULT.Name = "LablePACKFAULT"
        Me.LablePACKFAULT.Size = New System.Drawing.Size(159, 29)
        Me.LablePACKFAULT.TabIndex = 134
        Me.LablePACKFAULT.Text = "PACK FAULT"
        Me.LablePACKFAULT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LablePACKSTATE
        '
        Me.LablePACKSTATE.AutoSize = True
        Me.LablePACKSTATE.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LablePACKSTATE.Location = New System.Drawing.Point(820, 107)
        Me.LablePACKSTATE.Name = "LablePACKSTATE"
        Me.LablePACKSTATE.Size = New System.Drawing.Size(162, 29)
        Me.LablePACKSTATE.TabIndex = 135
        Me.LablePACKSTATE.Text = "PACK STATE"
        Me.LablePACKSTATE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LableBIN
        '
        Me.LableBIN.AutoSize = True
        Me.LableBIN.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LableBIN.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.LableBIN.Location = New System.Drawing.Point(12, 18)
        Me.LableBIN.Name = "LableBIN"
        Me.LableBIN.Size = New System.Drawing.Size(73, 37)
        Me.LableBIN.TabIndex = 136
        Me.LableBIN.Text = "BIN"
        Me.LableBIN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBoxPackVoltage
        '
        Me.TextBoxPackVoltage.Location = New System.Drawing.Point(1169, 248)
        Me.TextBoxPackVoltage.Name = "TextBoxPackVoltage"
        Me.TextBoxPackVoltage.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxPackVoltage.TabIndex = 137
        '
        'TexBoxtCTHead
        '
        Me.TexBoxtCTHead.Location = New System.Drawing.Point(1169, 283)
        Me.TexBoxtCTHead.Name = "TexBoxtCTHead"
        Me.TexBoxtCTHead.Size = New System.Drawing.Size(100, 20)
        Me.TexBoxtCTHead.TabIndex = 138
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Maroon
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.LableCV1)
        Me.GroupBox1.Controls.Add(Me.LableCV2)
        Me.GroupBox1.Controls.Add(Me.LableCV3)
        Me.GroupBox1.Controls.Add(Me.LableCV4)
        Me.GroupBox1.Controls.Add(Me.LableCV5)
        Me.GroupBox1.Controls.Add(Me.LableCV6)
        Me.GroupBox1.Controls.Add(Me.LableCV7)
        Me.GroupBox1.Controls.Add(Me.LableCV8)
        Me.GroupBox1.Controls.Add(Me.LableCV9)
        Me.GroupBox1.Controls.Add(Me.LableCV10)
        Me.GroupBox1.Controls.Add(Me.LableCV11)
        Me.GroupBox1.Controls.Add(Me.LableCV12)
        Me.GroupBox1.Controls.Add(Me.LableCV13)
        Me.GroupBox1.Controls.Add(Me.LableCV14)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 219)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1287, 84)
        Me.GroupBox1.TabIndex = 139
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Cell Voltages (mV)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(16, 66)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 15)
        Me.Label4.TabIndex = 116
        Me.Label4.Text = "CV1"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(106, 66)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 15)
        Me.Label5.TabIndex = 117
        Me.Label5.Text = "CV2"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(196, 66)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 15)
        Me.Label6.TabIndex = 118
        Me.Label6.Text = "CV3"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(286, 66)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 15)
        Me.Label8.TabIndex = 119
        Me.Label8.Text = "CV4"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(376, 66)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(29, 15)
        Me.Label9.TabIndex = 120
        Me.Label9.Text = "CV5"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(466, 66)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(29, 15)
        Me.Label10.TabIndex = 121
        Me.Label10.Text = "CV6"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(556, 66)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(29, 15)
        Me.Label11.TabIndex = 122
        Me.Label11.Text = "CV7"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(646, 66)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(29, 15)
        Me.Label12.TabIndex = 123
        Me.Label12.Text = "CV8"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(736, 66)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(29, 15)
        Me.Label13.TabIndex = 124
        Me.Label13.Text = "CV9"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(826, 66)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(36, 15)
        Me.Label14.TabIndex = 125
        Me.Label14.Text = "CV10"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(926, 66)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(36, 15)
        Me.Label15.TabIndex = 126
        Me.Label15.Text = "CV11"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(1026, 66)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(36, 15)
        Me.Label16.TabIndex = 127
        Me.Label16.Text = "CV12"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(1126, 66)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(36, 15)
        Me.Label17.TabIndex = 128
        Me.Label17.Text = "CV13"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(1226, 66)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(36, 15)
        Me.Label18.TabIndex = 129
        Me.Label18.Text = "CV14"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(2, 23)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(107, 54)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 116
        Me.PictureBox3.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Maroon
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.Label24)
        Me.GroupBox2.Controls.Add(Me.LableCT5)
        Me.GroupBox2.Controls.Add(Me.LableCT1)
        Me.GroupBox2.Controls.Add(Me.LableCT2)
        Me.GroupBox2.Controls.Add(Me.LableCT3)
        Me.GroupBox2.Controls.Add(Me.LableCT4)
        Me.GroupBox2.Controls.Add(Me.LableCT6)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.GroupBox2.Location = New System.Drawing.Point(775, 309)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(521, 76)
        Me.GroupBox2.TabIndex = 140
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Pack Temperature (oC)"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(377, 56)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(29, 15)
        Me.Label19.TabIndex = 126
        Me.Label19.Text = "CT5"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(13, 56)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(29, 15)
        Me.Label20.TabIndex = 122
        Me.Label20.Text = "CT1"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(104, 56)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(29, 15)
        Me.Label21.TabIndex = 123
        Me.Label21.Text = "CT2"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(195, 56)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(29, 15)
        Me.Label22.TabIndex = 124
        Me.Label22.Text = "CT3"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(286, 56)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(29, 15)
        Me.Label23.TabIndex = 125
        Me.Label23.Text = "CT4"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(468, 56)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(29, 15)
        Me.Label24.TabIndex = 127
        Me.Label24.Text = "CT6"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Maroon
        Me.GroupBox3.Controls.Add(Me.TextBoxPACKFAULT)
        Me.GroupBox3.Controls.Add(Me.LablePV)
        Me.GroupBox3.Controls.Add(Me.LablePC)
        Me.GroupBox3.Controls.Add(Me.LablePACKSTATE)
        Me.GroupBox3.Controls.Add(Me.LableSOC)
        Me.GroupBox3.Controls.Add(Me.LableSOH)
        Me.GroupBox3.Controls.Add(Me.LablePACKFAULT)
        Me.GroupBox3.Controls.Add(Me.LablePE)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.GroupBox3.Location = New System.Drawing.Point(12, 68)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(1082, 145)
        Me.GroupBox3.TabIndex = 141
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "BMS Status"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Gainsboro
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(125, 111)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 24)
        Me.Label3.TabIndex = 142
        Me.Label3.Text = "Port"
        '
        'BoudRate
        '
        Me.BoudRate.AutoSize = True
        Me.BoudRate.BackColor = System.Drawing.Color.Gainsboro
        Me.BoudRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BoudRate.ForeColor = System.Drawing.Color.Black
        Me.BoudRate.Location = New System.Drawing.Point(98, 147)
        Me.BoudRate.Name = "BoudRate"
        Me.BoudRate.Size = New System.Drawing.Size(75, 17)
        Me.BoudRate.TabIndex = 143
        Me.BoudRate.Text = "Baud Rate"
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Maroon
        Me.GroupBox4.Controls.Add(Me.TextBoxFPath)
        Me.GroupBox4.Controls.Add(Me.PictureBox3)
        Me.GroupBox4.Controls.Add(Me.Button1)
        Me.GroupBox4.Controls.Add(Me.Button4)
        Me.GroupBox4.Controls.Add(Me.BoudRate)
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Controls.Add(Me.ComboBox1)
        Me.GroupBox4.Controls.Add(Me.ComboBox2)
        Me.GroupBox4.Controls.Add(Me.RichTextBox2)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.Thistle
        Me.GroupBox4.Location = New System.Drawing.Point(1100, 2)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(200, 211)
        Me.GroupBox4.TabIndex = 144
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Connect BMS"
        '
        'TextBoxFPath
        '
        Me.TextBoxFPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxFPath.BackColor = System.Drawing.Color.White
        Me.TextBoxFPath.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxFPath.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxFPath.Location = New System.Drawing.Point(6, 84)
        Me.TextBoxFPath.Name = "TextBoxFPath"
        Me.TextBoxFPath.Size = New System.Drawing.Size(183, 19)
        Me.TextBoxFPath.TabIndex = 153
        Me.TextBoxFPath.Text = "Enter Database Path"
        '
        'PVAxis
        '
        Me.PVAxis.BackColor = System.Drawing.Color.Maroon
        Me.PVAxis.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.PVAxis.ForeColor = System.Drawing.Color.Maroon
        Me.PVAxis.Location = New System.Drawing.Point(796, 31)
        Me.PVAxis.Name = "PVAxis"
        Me.PVAxis.Size = New System.Drawing.Size(100, 13)
        Me.PVAxis.TabIndex = 146
        '
        'TextBoxCount
        '
        Me.TextBoxCount.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxCount.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxCount.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxCount.Location = New System.Drawing.Point(488, 47)
        Me.TextBoxCount.Name = "TextBoxCount"
        Me.TextBoxCount.Size = New System.Drawing.Size(82, 13)
        Me.TextBoxCount.TabIndex = 147
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Maroon
        Me.Label7.ForeColor = System.Drawing.Color.Maroon
        Me.Label7.Location = New System.Drawing.Point(819, 12)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(71, 13)
        Me.Label7.TabIndex = 51
        Me.Label7.Text = "Pack Voltage"
        '
        'TextBoxCT
        '
        Me.TextBoxCT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxCT.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxCT.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxCT.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxCT.Location = New System.Drawing.Point(576, 49)
        Me.TextBoxCT.Name = "TextBoxCT"
        Me.TextBoxCT.Size = New System.Drawing.Size(76, 13)
        Me.TextBoxCT.TabIndex = 148
        '
        'TextBoxPackState
        '
        Me.TextBoxPackState.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxPackState.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxPackState.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxPackState.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxPackState.Location = New System.Drawing.Point(562, 12)
        Me.TextBoxPackState.Name = "TextBoxPackState"
        Me.TextBoxPackState.Size = New System.Drawing.Size(76, 13)
        Me.TextBoxPackState.TabIndex = 149
        '
        'TextBoxFAULT
        '
        Me.TextBoxFAULT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxFAULT.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxFAULT.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxFAULT.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxFAULT.Location = New System.Drawing.Point(528, 31)
        Me.TextBoxFAULT.Name = "TextBoxFAULT"
        Me.TextBoxFAULT.Size = New System.Drawing.Size(76, 13)
        Me.TextBoxFAULT.TabIndex = 150
        '
        'TextBoxDataset
        '
        Me.TextBoxDataset.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxDataset.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxDataset.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxDataset.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxDataset.Location = New System.Drawing.Point(611, 31)
        Me.TextBoxDataset.Name = "TextBoxDataset"
        Me.TextBoxDataset.Size = New System.Drawing.Size(100, 13)
        Me.TextBoxDataset.TabIndex = 151
        '
        'TextBoxBIN
        '
        Me.TextBoxBIN.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxBIN.BackColor = System.Drawing.Color.Maroon
        Me.TextBoxBIN.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxBIN.ForeColor = System.Drawing.Color.Maroon
        Me.TextBoxBIN.Location = New System.Drawing.Point(576, 50)
        Me.TextBoxBIN.Name = "TextBoxBIN"
        Me.TextBoxBIN.Size = New System.Drawing.Size(100, 13)
        Me.TextBoxBIN.TabIndex = 152
        '
        'Dashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Maroon
        Me.ClientSize = New System.Drawing.Size(1301, 593)
        Me.Controls.Add(Me.TextBoxBIN)
        Me.Controls.Add(Me.TextBoxDataset)
        Me.Controls.Add(Me.TextBoxFAULT)
        Me.Controls.Add(Me.TextBoxPackState)
        Me.Controls.Add(Me.TextBoxCT)
        Me.Controls.Add(Me.TextBoxPV)
        Me.Controls.Add(Me.TextBoxPC)
        Me.Controls.Add(Me.TextBoxPE)
        Me.Controls.Add(Me.TextBoxCV)
        Me.Controls.Add(Me.TextBoxSoH)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TextBoxCount)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.LableBIN)
        Me.Controls.Add(Me.PVAxis)
        Me.Controls.Add(Me.Chart2)
        Me.Controls.Add(Me.Chart1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBoxSoC)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.TextBoxCTHEAD)
        Me.Controls.Add(Me.TextBox28)
        Me.Controls.Add(Me.TextBoxPackVoltage)
        Me.Controls.Add(Me.TexBoxtCTHead)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Dashboard"
        Me.Text = "BMS Monitoring (ESMITO Solutions PVT LTD)"
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents ModuleBar1 As ProgressBar
    Friend WithEvents TrackBar1 As TrackBar
    Friend WithEvents TextBoxPV As TextBox
    Friend WithEvents TextBoxPC As TextBox
    Friend WithEvents TextBoxPE As TextBox
    Friend WithEvents TextBoxCV As TextBox
    Friend WithEvents LablePV As Label
    Friend WithEvents LablePE As Label
    Friend WithEvents Chart1 As DataVisualization.Charting.Chart
    Friend WithEvents TextBoxPACKFAULT As TextBox
    Friend WithEvents TextBox28 As TextBox
    Friend WithEvents TextBoxCTHEAD As TextBox
    Friend WithEvents TextBoxSoH As TextBox
    Friend WithEvents TextBoxSoC As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Public WithEvents Timer1 As Timer
    Friend WithEvents LableCV1 As Label
    Friend WithEvents LableCV2 As Label
    Friend WithEvents LableCV3 As Label
    Friend WithEvents LableCV4 As Label
    Friend WithEvents LableCV5 As Label
    Friend WithEvents LableCV6 As Label
    Friend WithEvents LableCV7 As Label
    Friend WithEvents LableCV8 As Label
    Friend WithEvents LableCV9 As Label
    Friend WithEvents LableCV10 As Label
    Friend WithEvents LableCV11 As Label
    Friend WithEvents LableCV12 As Label
    Friend WithEvents LableCV13 As Label
    Friend WithEvents LableCV14 As Label
    Friend WithEvents LableCT1 As Label
    Friend WithEvents LableCT2 As Label
    Friend WithEvents LableCT3 As Label
    Friend WithEvents LableCT4 As Label
    Friend WithEvents LableCT5 As Label
    Friend WithEvents LableCT6 As Label
    Friend WithEvents Chart2 As DataVisualization.Charting.Chart
    Friend WithEvents LablePC As Label
    Friend WithEvents LableSOC As Label
    Friend WithEvents LableSOH As Label
    Friend WithEvents LablePACKFAULT As Label
    Friend WithEvents LablePACKSTATE As Label
    Friend WithEvents LableBIN As Label
    Friend WithEvents TextBoxPackVoltage As TextBox
    Friend WithEvents TexBoxtCTHead As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents BoudRate As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents PVAxis As TextBox
    Friend WithEvents TextBoxCount As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TextBoxCT As TextBox
    Friend WithEvents TextBoxPackState As TextBox
    Friend WithEvents TextBoxFAULT As TextBox
    Friend WithEvents TextBoxDataset As TextBox
    Friend WithEvents TextBoxBIN As TextBox
    Friend WithEvents TextBoxFPath As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
End Class
